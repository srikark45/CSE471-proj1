#pragma once
#include "AudioNode.h"
#include "Note.h"
//#include <map>

class CInstrument :
    public CAudioNode
{
public:
    virtual void SetNote(CNote* note) = 0;
    //bool hasEffect(int effect) { return m_effects[effect]; }
    //void setEffect(int effect) { m_effects[effect] = true; }
    //int getNumEffects();
private:
    //std::map<int, bool> m_effects;
};

